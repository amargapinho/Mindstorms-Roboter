﻿
using System.Threading;
using MonoBrickFirmware.Movement;

namespace Aufgabe_1._1
{
    class Program
    {
        static void Main(string[] args)
        {
            Motor motorRechts = new Motor(MotorPort.OutC);
            Motor motorLinks = new Motor(MotorPort.OutB);

            //Der Roboter dreht sich nach rechts, vorwärts
            Fahren(motorRechts, motorLinks, 30, 75);
            Thread.Sleep(1000);

            //Der Roboter dreht sich nach links, rückwärts
            Fahren(motorRechts, motorLinks, -75, -30);
            Thread.Sleep(1000);

            //Der Roboter fährt geradeaus, vorwärts
            Fahren(motorRechts, motorLinks, 50, 50);
        }

        private static void Fahren(Motor motorRechts, Motor motorLinks, sbyte leistungRechts, sbyte leistungLinks)
        {
            motorRechts.SetSpeed(leistungRechts);
            motorLinks.SetSpeed(leistungLinks);
        }
    }
}
